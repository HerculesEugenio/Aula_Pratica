from django.apps import AppConfig


class VendaIngressoConfig(AppConfig):
    name = 'Venda_Ingresso'
