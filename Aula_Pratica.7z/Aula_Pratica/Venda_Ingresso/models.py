from django.db import models

class Pessoa(models.Model):
    class Meta:
        verbose_name='Pessoa'
        verbose_name_plural='Pessoas'
    nome = models.CharField('Nome', max_length=128,blank=True,null=True)
    email = models.EmailField('Email', max_length=128,blank=True,null=True)
    
    def __str__(self):
        return self.nome

class PessoaFisica(Pessoa):
    cpf = models.CharField('CPF',max_length = 11,blank=True,null=True)
    
class Evento(models.Model):
    class Meta:
        verbose_name='Evento'
        verbose_name_plural='Eventos'
    nome = models.CharField('Nome', max_length=128,blank=True,null=True)
    sigla = models.CharField('Sigla', max_length=128,blank=True,null=True)
    data_inicio = models.DateTimeField('Data Início',blank=True,null=True)
    realizador = models.ForeignKey(PessoaFisica,on_delete=models.CASCADE)
    descricao = models.TextField('Descrição', max_length=500,blank=True,null=True)

    def __str__(self):
        return self.nome

class Ingresso(models.Model):
    class Meta:
        verbose_name='Ingresso'
        verbose_name_plural='Ingressos'
    descricao = models.CharField('Descrição', max_length=128,blank=True,null=True)
    valor = models.FloatField('Valor',blank=True,null=True)
    evento = models.ForeignKey(Evento, on_delete=models.SET_NULL,null=True)

    def __str__(self):
        return self.descricao

class Inscricao(models.Model):
    class Meta:
        verbose_name='Inscrição'
        verbose_name_plural='Inscrições'
    pessoa = models.ForeignKey(PessoaFisica,on_delete=models.SET_NULL,null=True,blank=True)
    evento = models.ForeignKey(Evento,on_delete=models.SET_NULL,null=True,blank=True)
    ingresso = models.ForeignKey(Ingresso,on_delete=models.SET_NULL,null=True,blank=True)
