from django.contrib import admin
from .models import PessoaFisica, Evento, Ingresso, Inscricao

@admin.register(PessoaFisica,Evento,Ingresso, Inscricao)
class EventoAdmin(admin.ModelAdmin):
    pass